<!--Template Name:Eatry
File Name:reservation.html
Author Name: ThemeVault
Author URI: http://www.themevault.net/
License URI: http://www.themevault.net/license/-->
<?php
          session_start();
           $conn= new mysqli('localhost', 'root', '', 'food_online') or die("Unable to connect");?>
<!DOCTYPE html>
<html>
    <head>
        <title>Online Food Ordering System</title>

        <!--Meta Tag-->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="images/favicon.png" rel="icon"/>
        <!--End Meta Tag-->

        <!--Fonts-->
        <link href="fonts/elegant_font/css/style.css" rel="stylesheet">
        <link href="fonts/et-line-font/style.css" rel="stylesheet">
        <!--End Fonts-->

        <!--CSS Link-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/owl.theme.default.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">
        <!--End CSS Link-->

        <!--JS Link-->
        <script src= "js/jquery.min.js" type= "text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/owl.carousel.js" type="text/javascript"></script>
        <script src="js/custom.js" type="text/javascript"></script>
        <!--End JS Link-->
        <style>
            table th{
            background-color: #efefef;
        }
    </style>

    </head>

    <body>

        <!--Header Of Site-->
        <header>
            <!--Top Header Section-->
            <div class="tv-header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 col-sm-12">
                            <div class="tv-headertopwidget">
                                <div class="tv-headertop-details">
                                    <p><i class="fa fa-envelope-o"></i>Email: <a href="#">foodon123@gmail.com</a></p>
                                    <p><i class="fa fa-phone"></i>Telephone: <a href="#">+92 334 234 5678</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12">
                            <div class="tv-headertopwidget">
                                <div class="tv-booktable-button">
                                    <a href="order.php">Order Online</a>
                                </div>
                                <div class="tv-header-social">
                                    <ul>
                                        <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                        <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href=""><i class="fa fa-behance"></i></a></li>
                                        <li><a href=""><i class="fa fa-feed"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Top Header Section-->

            <!--Navigation-->
            <nav class="navbar navbar-default tv-navbar-custom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <div class="navbar-header">
                                                               <!-- <a href="home.html" class="navbar-brand tv-bakeat-logo"><span>Bakeat</span>Hunt</a> -->
                                <a href="index.php"><img src="images/logo.png"></a>
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#tv-navbar">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8 col-sm-12 col-xs-12">
                            <div class="collapse navbar-collapse" id="tv-navbar">
                                <ul class="nav navbar-nav text-center">
                                   <li class=""><a href="index.php" class="tv-menu">Home</a></li>
                                    <li class=""><a href="shoppingcart.php" class="tv-menu">Our Menu</a></li>
                                    <li class="tv-drop-menu">
                                        <a data-toggle="dropdown" aria-expanded="false" class="tv-menu">Reservation<i class="fa fa-angle-down"></i></a>
                                        <ul class="dropdown-menu tv-sub-menu">
                                            <li class="dropdown-submenu Navigation-listItem is-dropdown ">
                                                <a href="order.php">Order Online</a>
                                                <a href="booktable.html">Book A Table</a>
                                            </li>
                                        </ul>
                                    </li>
                                   <li class=""><a href="aboutusfood.html" class="tv-menu">AboutUs</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <!--End Navigation-->

            <!--Banner Section-->
            <div class="tv-banner-image" style="background: rgba(0, 0, 0, 0) url('images/order.jpg') no-repeat scroll center top / cover;">
                <div class="tv-opacity-medium tv-bg-black"></div>
                <div class="tv-banner-info">
                    <h1>Order Online</h1>
                </div>
            </div>
            <!--End Banner Section-->
        </header>
        <!--End Header Of Site-->
           <div style= "clear: both"></div>
   <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Shopping Cart Details</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                
   <div class="table-responsive">
      <table class= "table table-bordered">
        <tr>
           <th width="36%">Name</th>
           <th width="16%">Quantity</th>
           <th width="13%">Price Details</th>
           <th width="10%">Total Price</th>
           <th width="17%">Remove</th>
        </tr>  
    <?php
        if(!empty($_SESSION["shopping_cart"])){
            $total= 0;
            foreach($_SESSION["shopping_cart"] as $key => $value){

           
    ?> 
        <tr>
           <td><?php echo $value["item_name"];?></td>
           <td><?php echo $value["item_quantity"];?></td>
           <td><i class="fa fa-rupee"></i><?php echo $value["product_price"];?></td>
           <td><i class="fa fa-rupee"></i><?php echo number_format( $value["item_quantity"] * $value["product_price"], 2);?> </td>
           <td><a href="shoppingcart.php?action=delete&id=<?php echo $value["product_id"];?>"><span class="text-danger">Remove</span></a></td>
 
        
        
        </tr>
        <?php 

               $total = $total + ($value["item_quantity"] * $value["product_price"]);
            }
        ?>
        <tr>
           <td colspan="3" align="right">Total</td>
           <td  align="right"><i class="fa fa-rupee"></i><?php echo number_format($total, 2)?></td>
           <td></td>
        </tr>
        <?php
            }
        
        ?>

        </div>
      </table>
    </div>
</div>
        <!--Book Table-->
        <section class="tv-section-padding">
            <div class="container">
                <div class="row">
                    <div class="reservation-form">
                        <form name="form" action="working.php" method="post">
                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <input class="form-control" name="name"
                                placeholder="Name" required type="text">
                            </div>
                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <input class="form-control" placeholder="Email" name="email" required="" type="email">
                            </div>
                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <input class="form-control" name="contact" placeholder="Contact Number" required type="text">
                            </div>
                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <input class="form-control" name="code" placeholder="Zip code" required type="text">
                            </div>
                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                <textarea class="form-control" rows="10" name="order" placeholder="Order Details" required></textarea>
                            </div>
                            <div class="form-group col-md-12 col-sm-12 col-xs-12 text-center">
                                <div class="tv-eatry-button"><a href="Submission.html"><button type="submit" name="submit">Order Now <span class="arrow_right"></span></button></a></div>
                            </div>
                            <!-- <div class="col-md-6 col-sm-6 col-xs-12">
                                <input name="name" class="form-control" placeholder="Name" required="" type="text">
                            </div>

                             <div class="col-md-6 col-sm-6 col-xs-12">
                                <table class="table"> 
                                <thead> 
                                  <tr>
                                   <th>Dish</th>
                                   <th>Quantity</th>
                                   <th>Cost</th>
                                   </tr>
                                   </table>
                            </div>

                            <br>
                            
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input name="email" class="form-control" placeholder="Email" required="" type="email">
                            </div>
                            <br>

                            <div class="col-md-7 col-sm-7 col-xs-12">
                                <input name="contact" class="form-control" placeholder="Contact Number" required="" type="text">
                            </div>
                            <br>
                            
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input name="code" class="form-control" placeholder="ZIP CODE" required="" type="text">
                            </div>
                            <br>

                            <div class="col-md-7 col-sm-7 col-xs-12">
                                <textarea name="order" class="form-control" rows="5" placeholder="ORDER DETAILS" required=""></textarea>
                            </div>
                            <br>

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="tv-eatry-button"><button type="submit">Order Now <span class="arrow_right"></span></button></div>
                            </div> -->
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--Book Table-->

        

        <!--Insta Owl Script-->
        <script>
            $(document).ready(function () {
                $('#instaowl').owlCarousel({
                    margin: 10,
                    autoWidth: false,
                    nav: false,
                    items: 5,
                    dots: true,
                    navText: ["<img src='images/Image19.png'>", "<img src='images/Image18.png'>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 1
                        },
                        700: {
                            items: 3
                        },
                        1000: {
                            items: 5
                        }
                    }
                });
            });
        </script>
        <!--End Insta Owl Script-->

        <!--End Instagram Section-->

        <!--Footer Section-->
        <section class="tv-section-footer-padding ">
            <div class="container backlink-top">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12 padding-0">
                        <div class="tv-footer-menu">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="aboutusfood.html">About Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 padding-0">
                        <div class="tv-copyright">
                            <!--Do not remove Backlink from footer of the template. To remove it you can purchase the Backlink !-->
                            <p>&copy; All right reserved. Designed by <a href="https://www.themevault.net">ThemeVault</a> </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Footer Section-->

        <a id="back-to-top" class="animated bounce" style="display: none;"><i class="fa fa-caret-up fa-lg"></i></a>
    </body>   
</html>
