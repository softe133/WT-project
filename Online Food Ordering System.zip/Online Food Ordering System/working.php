<?php

$name= $_POST['name']; 
$email= $_POST['email']; 
$contact= $_POST['contact']; 
$code= $_POST['code']; 
$order= $_POST['order']; 

//echo($name.$email.$code.$contact.$order);

$conn= mysqli_connect("localhost","root","","food_online") or die("connection failed because ".mysqli_connect_error());



// if($db){
// 	echo "connected";
// }
// else{
// 	echo "error in connection";
// }
$sql= "INSERT INTO order_online (name, email, contact, zip_code, details)
VALUES ('$name', '$email', '$contact', '$code', '$order')";

mysqli_query($conn, $sql);

//if($conn->query($sql)==TRUE){
//	echo "New record created successfully";
//}
//else{
//	echo "Error: ".$sql."<br>".$conn->error;
//}

//$conn->close();
// if($q){
// 	echo "successful";
// }
// else{
// 	echo "unsuccessful"
// }
if(isset($_POST['submit'])){
    $to = "haffsamahnoor123@gmail.com"; // this is your admin address
    $from = $_POST['email']; // this is the recipitent Email address
    $first_name = $_POST['name'];
    $phone_no = $_POST['contact'];
    $duration = $_POST['order'];
    $subject = "Form submission";// email subject for admin
    $subject2 = "Copy of your form submission";// email subject for sender
    $message1 = $first_name . " " . $phone_no. " " .$duration. " wrote the following:" . "\n\n" . $_POST['order']. "\n\n" . "For food Delivery.";// message to admin
    $message2 = "Your order has been registered " . $first_name . "\n\n" . $_POST['order']; // sends a copy of form submission to sender

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message1,$headers);
    mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
    // echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly.";
   
    }
?>