<?php

session_start();
$conn= new mysqli('localhost', 'root', '', 'food_online') or die("Unable to connect");
//echo "connection successful";

if(isset($_POST["add"])){
    if(isset($_SESSION["shopping_cart"])){
        $item_array_id = array_column($_SESSION['shopping_cart'], "product_id");
        if(!in_array($_GET['id'],$item_array_id)){
            $count= count($_SESSION['shopping_cart']);
            $item_array = array(
                'product_id'=> $_GET['id'],
                'item_name' => $_POST['hidden_name'],
                'product_price' =>$_POST['hidden_price'],
                'item_quantity' => $_POST['quantity'],
            );
            $_SESSION['shopping_cart'][$count] = $item_array;
            echo '<script>window.location="shoppingcart.php"</script>';
        }
        else {
            echo '<script>alert("Product is already added to the Cart")</script>';
            echo '<script>window.location="shoppingcart.php"</script>';
         }
       
    }else {
        $item_array = array(
            'product_id'=> $_GET['id'],
            'item_name' => $_POST['hidden_name'],
            'product_price' =>$_POST['hidden_price'],
            'item_quantity' => $_POST['quantity'],
        );
        $_SESSION['shopping_cart'][0] = $item_array;
    }
}

     if(isset($_GET['action'])){
         if($_GET['action']== "delete"){
             foreach ($_SESSION["shopping_cart"] as $keys => $value){
                if($value['product_id'] == $_GET['id']){
                    unset($_SESSION["shopping_cart"][$keys]);
                    echo '<script>alert("Product has been removed from the Cart")</script>';
                    echo '<script>window.location="shoppingcart.php"</script>';
                }

             }        
            
        }

     }












?>
<!DOCTYPE html>
<html>
    <head>
        <title>Eatry</title>

        <!--Meta Tag-->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="images/favicon.png" rel="icon"/>
        <!--End Meta Tag-->

        <!--Fonts-->
        <link href="fonts/elegant_font/css/style.css" rel="stylesheet">
        <link href="fonts/et-line-font/style.css" rel="stylesheet">
        <!--End Fonts-->

        <!--CSS Link-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/owl.theme.default.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">
        <!--End CSS Link-->

        <!--JS Link-->
        <script src= "js/jquery.min.js" type= "text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/owl.carousel.js" type="text/javascript"></script>
        <script src="js/custom.js" type="text/javascript"></script>
        <!--End JS Link-->

    </head>

    <body>

        <!--Header Of Site-->
        <header>
            <!--Top Header Section-->
            <div class="tv-header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 col-sm-12">
                            <div class="tv-headertopwidget">
                                <div class="tv-headertop-details">
                                    <p><i class="fa fa-envelope-o"></i>Email: <a href="#">foodon123@gmail.com</a></p>
                                    <p><i class="fa fa-phone"></i>Telephone: <a href="#">+92 334 234 5678</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12">
                            <div class="tv-headertopwidget">
                                <div class="tv-booktable-button">
                                    <a href="booktable.html">Book a table</a>
                                </div>
                                <div class="tv-header-social">
                                    <ul>
                                        <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                        <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href=""><i class="fa fa-behance"></i></a></li>
                                        <li><a href=""><i class="fa fa-feed"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Top Header Section-->

            <!--Navigation-->
            <nav class="navbar navbar-default tv-navbar-custom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <div class="navbar-header">
                                <!--                                <a href="home.html" class="navbar-brand tv-bakeat-logo"><span>Bakeat</span>Hunt</a>-->
                                <a href="index.php"><img src="images/logo.png"></a>
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#tv-navbar">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8 col-sm-12 col-xs-12">
                            <div class="collapse navbar-collapse" id="tv-navbar">
                                <ul class="nav navbar-nav text-center">
                                    <li class=""><a href="index.php" class="tv-menu">Home</a></li>
                                    <li class=""><a href="shoppingcart.php" class="tv-menu">Our Menu</a></li>
                                    <li class="tv-drop-menu">
                                        <a data-toggle="dropdown" aria-expanded="false" class="tv-menu">Reservation<i class="fa fa-angle-down"></i></a>
                                        <ul class="dropdown-menu tv-sub-menu">
                                            <li class="dropdown-submenu Navigation-listItem is-dropdown ">
                                                <a href="order.php">Order Online</a>
                                                <a href="booktable.html">Book A Table</a>
                                            </li>
                                        </ul>
                                    </li>
                                   <li class=""><a href="aboutusfood.html" class="tv-menu">AboutUs</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <!--End Navigation-->

            <!--Banner Section-->
            <div class="tv-banner-image" style="background: rgba(0, 0, 0, 0) url('images/newmenu.jpg') no-repeat scroll center top / cover;">
                <div class="tv-opacity-medium tv-bg-black"></div>
                <div class="tv-banner-info">
                    <h1>Our Menu</h1>
                </div>
            </div>
            <!--End Banner Section-->
        </header>
        <!--End Header Of Site-->
 







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping cart</title>
   <!-- Latest compiled and minified CSS-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!--jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

 <!--Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<!--Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<!--font awesome link-->
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">



<!--font family Google-->
<style>
@import url('https://fonts.googleapis.com/css?family=Titillium+Web');
*{
    font-family: 'Titillium Web', sans-serif;
}
.product{
    border: 1px solid #eaeaec;
    margin: -1px 19px 3px -1px;
    padding: 10px;
    text-align: center;
    background-color: #efefef;
    padding: 2%;
}
table, th, tr{
    text-align: center;
}

h4{
    text-align: center;
    color: #66afe9;
    background-color: #efefef;
    padding: 2%;
}
table th{
    background-color: #efefef;
}
#cards12{
    margin-left: 10%;
    margin-right: 5%;
    padding-bottom: 0%;
    



}
</style>
</head>

<body>

<!--<div class="container" style="width: 85%">
<h2 class="title1"> Shopping cart</h2>-->
<section class='tv-section-padding'>
            <div class="container" width=100% >
                <div class="row">
                    <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Breakfast</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                    </div>
                </div>
             </div>


                                <?php
                                  $query= "SELECT * from newmenu where item_category like 'breakfast';";
                                  $result= mysqli_query($conn, $query);

                                while($rows = mysqli_fetch_array($result)){
      

                            ?>
                     <div class="col-md-4"    id="cards12"  max-height="300px";>
                        <form method="post" action="shoppingcart.php?action=add&id=<?php echo $rows["id"];?>" >
      
                            <div class="card h-200 "  style="background-image: linear-gradient(25deg, #0d0031, #4b092b, #810723, #b90015); border-radius: 5%; padding-bottom:0%">
                                <br>
                            <div class="text-center"><img src="<?php echo $rows["item_img"];?>" class= "img-fluid" alt="" height="150px" width="150px" style="border-radius:50%";>
                                <h3 class="text-danger text-center mt-10"><?php echo $rows["item_name"]; ?> &nbsp; <br><span class="text-danger text-right"><i class="fa fa-rupee"></i>
                                <?php echo $rows["item_price"];?></span></h3></div>
                                <div class="text-center" style="display: inline" float="left">
                                <input type=" text" name="quantity" value="1" class="form-control" style="width:50% ; text-align: center ; margin-left: 100px;"></div>
                                <input type="hidden" name="hidden_name" value="<?php echo $rows["item_name"];?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $rows["item_price"];?>">
                               <div class="text-center" float="right">
                                <input type="submit" name="add" value="Add to Cart" style="margin-top: 5px;" class="btn btn-success btn-center" width="20%">
                                </div>
<br>
                            </div>
                            <br><br> <br><br>
                        </form>
                                </div>
         

    </section>
    <?php 

}

?>
    <section>
                 <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Lunch</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                </div>
                <?php
                                  $query= "SELECT * from newmenu where item_category like '%lunch%';";
                                  $result= mysqli_query($conn, $query);

                                while($rows = mysqli_fetch_array($result)){
      

                            ?>
                                <div class="col-md-4"    id="cards12"  max-height="300px";>
                        <form method="post" action="shoppingcart.php?action=add&id=<?php echo $rows["id"];?>" >
      
                            <div class="card h-200 "  style="background-image: linear-gradient(25deg, #0d0031, #4b092b, #810723, #b90015); border-radius: 5%; padding-bottom:0%">
                                <br>
                            <div class="text-center"><img src="<?php echo $rows["item_img"];?>" class= "img-fluid" alt="" height="150px" width="150px" style="border-radius:50%";>
                                <h3 class="text-danger text-center mt-10"><?php echo $rows["item_name"]; ?> &nbsp; <br><span class="text-danger text-right"><i class="fa fa-rupee"></i>
                                <?php echo $rows["item_price"];?></span></h3></div>
                                <div class="text-center" style="display: inline" float="left">
                                <input type=" text" name="quantity" value="1" class="form-control" style="width:50% ; text-align: center ; margin-left: 100px;"></div>
                                <input type="hidden" name="hidden_name" value="<?php echo $rows["item_name"];?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $rows["item_price"];?>">
                               <div class="text-center" float="right">
                                <input type="submit" name="add" value="Add to Cart" style="margin-top: 5px;" class="btn btn-success btn-center" width="20%">
                                </div>
<br>
                            </div>
                            <br><br> <br><br>
                        </form>
                                </div>
                          

     </section>



        <?php 

        }
     
   ?>
    <section>
                 <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Dinner</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                </div>
                <?php
                                  $query= "SELECT * from newmenu where item_category like '%dinner%';";
                                  $result= mysqli_query($conn, $query);

                                while($rows = mysqli_fetch_array($result)){
      

                            ?>
                                <div class="col-md-4"    id="cards12"  max-height="300px";>
                        <form method="post" action="shoppingcart.php?action=add&id=<?php echo $rows["id"];?>" >
      
                            <div class="card h-200 "  style="background-image: linear-gradient(25deg, #0d0031, #4b092b, #810723, #b90015); border-radius: 5%; padding-bottom:0%">
                                <br>
                            <div class="text-center"><img src="<?php echo $rows["item_img"];?>" class= "img-fluid" alt="" height="150px" width="150px" style="border-radius:50%";>
                                <h3 class="text-danger text-center mt-10"><?php echo $rows["item_name"]; ?> &nbsp; <br><span class="text-danger text-right"><i class="fa fa-rupee"></i>
                                <?php echo $rows["item_price"];?></span></h3></div>
                                <div class="text-center" style="display: inline" float="left">
                                <input type=" text" name="quantity" value="1" class="form-control" style="width:50% ; text-align: center ; margin-left: 100px;"></div>
                                <input type="hidden" name="hidden_name" value="<?php echo $rows["item_name"];?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $rows["item_price"];?>">
                               <div class="text-center" float="right">
                                <input type="submit" name="add" value="Add to Cart" style="margin-top: 5px;" class="btn btn-success btn-center" width="20%">
                                </div>
<br>
                            </div>
                            <br><br> <br><br>
                        </form>
                                </div>
                          

     </section>



        <?php 

        }
     
   ?>
  
  <section>
                 <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Starters and Drinks</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                </div>
                <?php
                                  $query= "SELECT * from newmenu where item_category like 'starters' or item_category like 'drinks';";
                                  $result= mysqli_query($conn, $query);

                                while($rows = mysqli_fetch_array($result)){
      

                            ?>
                                <div class="col-md-4"    id="cards12"  max-height="300px";>
                        <form method="post" action="shoppingcart.php?action=add&id=<?php echo $rows["id"];?>" >
      
                            <div class="card h-200 "  style="background-image: linear-gradient(25deg, #0d0031, #4b092b, #810723, #b90015); border-radius: 5%; padding-bottom:0%">
                                <br>
                            <div class="text-center"><img src="<?php echo $rows["item_img"];?>" class= "img-fluid" alt="" height="150px" width="150px" style="border-radius:50%";>
                                <h3 class="text-danger text-center mt-10"><?php echo $rows["item_name"]; ?> &nbsp; <br><span class="text-danger text-right"><i class="fa fa-rupee"></i>
                                <?php echo $rows["item_price"];?></span></h3></div>
                                <div class="text-center" style="display: inline" float="left">
                                <input type=" text" name="quantity" value="1" class="form-control" style="width:50% ; text-align: center ; margin-left: 100px;"></div>
                                <input type="hidden" name="hidden_name" value="<?php echo $rows["item_name"];?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $rows["item_price"];?>">
                               <div class="text-center" float="right">
                                <input type="submit" name="add" value="Add to Cart" style="margin-top: 5px;" class="btn btn-success btn-center" width="20%">
                                </div>
<br>
                            </div>
                            <br><br> <br><br>
                        </form>
                                </div>
                          

     </section>



        <?php 

        }
     
   ?>
  
   <div style= "clear: both"></div>
   <div class="col-md-12">
                    <div class="tv-submenu-details">
                            <h2 class="text-center">Shopping Cart Details</h2>
                            <span class="tv-border-saparator"></span>
                            <br><br>
                    </div>
                
   <div class="table-responsive">
      <table class= "table table-bordered">
        <tr>
           <th width="36%">Name</th>
           <th width="16%">Quantity</th>
           <th width="13%">Price Details</th>
           <th width="10%">Total Price</th>
           <th width="17%">Remove</th>
        </tr>  
    <?php
        if(!empty($_SESSION["shopping_cart"])){
            $total= 0;
            foreach($_SESSION["shopping_cart"] as $key => $value){

           
    ?> 
        <tr>
           <td><?php echo $value["item_name"];?></td>
           <td><?php echo $value["item_quantity"];?></td>
           <td><i class="fa fa-rupee"></i><?php echo $value["product_price"];?></td>
           <td><i class="fa fa-rupee"></i><?php echo number_format( $value["item_quantity"] * $value["product_price"], 2);?> </td>
           <td><a href="shoppingcart.php?action=delete&id=<?php echo $value["product_id"];?>"><span class="text-danger">Remove</span></a></td>
 
        
        
        </tr>
        <?php 

               $total = $total + ($value["item_quantity"] * $value["product_price"]);
            }
        ?>
        <tr>
           <td colspan="3" align="right">Total</td>
           <td  align="right"><i class="fa fa-rupee"></i><?php echo number_format($total, 2)?></td>
           <td></td>
        </tr>
        <?php
            }
        
        ?>

        </div>
      </table>
    </div>
</div>
 <section class="tv-section-footer-padding " style="background-color: white;">
            <div class="container backlink-top">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12 padding-0">
                        <div class="tv-footer-menu">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="aboutusfood.html">About Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 padding-0" style="background-color: white;">
                        <div class="tv-copyright">
                            <!--Do not remove Backlink from footer of the template. To remove it you can purchase the Backlink !-->
                            <p>&copy; All right reserved. Designed by <a href="https://www.themevault.net">ThemeVault</a> </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</body>
</html> 