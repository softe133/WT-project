<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food_online";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname)or die("not connected to database");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$name= $_POST['name']; 
$email= $_POST['email']; 
$phone= $_POST['phone']; 
$time= $_POST['time']; 
$message= $_POST['message']; 

//echo($name.$email.$phone.$time.$message);


// if($db){
// 	echo "connected";
// }
// else{
// 	echo "error in connection";
// }
$sql= "INSERT INTO reservation (name,email,contact,time,message)VALUES('$name','$email','$phone','$time','$message')";

if($conn->query($sql)==TRUE){
	// echo "New record created successfully";
}
else{
	echo "Error: ".$sql."<br>".$conn->error;
}

$conn->close();
// if($q){
// 	echo "successful";
// }
// else{
// 	echo "unsuccessful"
// }
if(isset($_POST['submit'])){
    $to = "haffsamahnoor123@gmail.com"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $first_name = $_POST['name'];
    $phone_no = $_POST['phone'];
    $duration = $_POST['time'];
    $subject = "Form submission";// email subject for admin
    $subject2 = "Copy of your form submission";// email subject for sender
    $message1 = $first_name . " " . $phone_no. " " .$duration. " wrote the following:" . "\n\n" . $_POST['message']. "\n\n" . "For food Delivery.";// message to admin
    $message2 = "Your table has been booked". "\n\n" ."please be ontime " . $first_name . "\n\n" . $_POST['message']; // sends a copy of form submission to sender

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message1,$headers);
    mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
    // echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly.";
   
    }


?>

